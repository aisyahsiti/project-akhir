<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","", "flower");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>